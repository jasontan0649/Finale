//Done by Tan Kai Yuan, Boe Chang Horn, Chan Yun Hong

#include <vector>
#include <string>
using namespace std;

//Header file
#ifndef COMPUTEMENU_H_
#define COMPUTEMENU_H_

//compute function
/*
Programmer: Boe Chang Horn
Name:		computeMenu

task:		Print Computation Menu and return selection
data in:	N/A

data out:	choice of selection
*/
char computeMenu();
/*
Programmer: Boe Chang Horn
Name:		computeFunc

task:		Call computation functions
data in:	vector of title, 2D vector of data to compute 

data out:	N/A
*/
void computeFunc(vector<string>, vector<vector<double>>);



//Statistics function and menu
/*
Programmer: Tan Kai Yuan
Name:		statMenu

task:		run statistic functions, display and export output to HTML/txt
data in:	vector of title, 2D vector to compute

data out:	choice of selection
*/
void statMenu(vector<string>, vector<vector<double>>);

//Distinct function and menu
/*
Programmer: Tan Kai Yuan
Name:		distinctMenu

task:		run distinct functions, display and export output to HTML/txt
data in:	vector of title, 2D vector to compute

data out:	choice of selection
*/
void distinctMenu(vector<string>, vector<vector<double>>);

//Generate Histogram
void histogramMenu(vector<string>, vector<vector<double>>);

//data above and below mean
void abvBlwMean(vector<string>, vector<double>, vector<vector<double>>);

//Pearson correlation //LR
void pearsonAndLRMenu(vector<string>, vector<double>, vector<vector<double>>);

#endif