//Done by Tan Kai Yuan, Boe Chang Horn, Chan Yun Hong

#include <vector>
using namespace std;

//Header file
#ifndef COMMONF_H_
#define COMMONF_H_

/*
Programmer: Tan Kai Yuan
Name:		isNum

task:		Check string is a number
data in:	string to check

data out:	true if string is number else false
*/
bool isNum(string);
/*
Programmer: Tan Kai Yuan
Name:		round

task:		round number
data in:	number to round, decimal place

data out:	rounded number of decimal place
*/
double round(double, int);

/*
Programmer: Tan Kai Yuan
Name:		strRepeat

task:		repeat string n times
data in:	string to repeat, n times

data out:	repeated string with n times
*/
string strRepeat(string, int);
/*
Programmer: Tan Kai Yuan
Name:		toStr

task:		convert double to string with precision
data in:	number to convert, precision
data out:	string of number
*/
string toStr(double, int pre = -1); //custom build to string function

//Chan Yun Hong
string spaceNeeded(int);
string center(int, string);
string ljust(int, string);
string rjust(int, string);

//finf max size(length) in vector
int findMaxInVect(vector<string>);

//vector double to string
vector<string> vectDoubleString(vector<double>);



//transpose vector
/*
Programmer: Tan Kai Yuan
Name:		transposeV

task:		transpose 2D double vector
data in:	vector to transpose

data out:	transposed vector
*/
vector<vector<double>> transposeV(vector<vector<double>>);
/*
Programmer: Tan Kai Yuan
Name:		transposeV

task:		transpose 2D string vector
data in:	vector to transpose

data out:	transposed vector
*/
vector<vector<string>> transposeV(vector<vector<string>>);

//sort by column
/*
Programmer: Tan Kai Yuan
Name:		sortByCol

task:		sort 2D vector specific column
data in:	vector to sort, the position

data out:	sorted vector
*/
void sortByCol(vector<vector<double>>&, int);
/*
Programmer: Tan Kai Yuan
Name:		sortByRow

task:		sort 2D vector specific row
data in:	vector to sort, the position

data out:	sorted vector
*/
void sortByRow(vector<vector<double>>&, int);

//system function
/*
Programmer: Tan Kai Yuan
Name:		clrScr

task:		clear console
data in:	N/A

data out:	N/A
*/
void clrScr();
/*
Programmer: Tan Kai Yuan
Name:		getCh

task:		call _getch() function
data in:	N/A

data out:	_getch() value
*/
char getCh();

//Menu function
char getChoice(char, char);
int selVector(vector<string>, string extra = "null");

#endif